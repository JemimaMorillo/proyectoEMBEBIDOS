/*
 * LCD16X2.c
 *
 * Created: 28/07/2019 21:11:48
 *  Author: Marlon
 */ 
 
 #include "LCD16X2.h"

 void lcd_start()
 {
	PORTC &=~ (1<<PORTC0);
	_delay_us(1);
	PORTC |=  (1<<PORTC0);
 }

 void lcd_write(uint8_t type, uint8_t inst_data)
 {
	if (type)
		PORTC |=  (1<<PORTC1);
	else
		PORTC &=~ (1<<PORTC1);

	PORTD = (PIND & 0x0F) | (inst_data & 0xF0);
	lcd_start();
	PORTD = (PIND & 0x0F) | ((inst_data<<4) & 0xF0);
	lcd_start();
	_delay_ms(2);
 }

 void lcd_init()
 {
	DDRC  |=  (1<<DDC0) | (1<<DDC1)| (1<<DDC2);	
	DDRD  |=  0xF0;
	
	PORTC &=~ ((1<<PORTC0) | (1<<PORTC0)| (1<<DDC2));
	
	PORTD  = (PIND & 0x0F) | 0x30;

	_delay_ms(100);
	lcd_start();
	_delay_ms(5);
	lcd_start();
	_delay_us(100);
	lcd_start();
	_delay_us(100);

	PORTD = (PIND & 0x0F) | 0x20;
	
	lcd_start();
	_delay_us(100);

	lcd_write(LCD_INST, 0x2C);
	lcd_write(LCD_INST, 0x08);
	lcd_write(LCD_INST, 0x01);
	lcd_write(LCD_INST, 0x06);	
	
	lcd_write(LCD_INST, 0x0C);
 }

void lcd_print(char *s)
{
	while(*s)
	{
		lcd_write(LCD_DATA, *s);
		s++;
	}
}
