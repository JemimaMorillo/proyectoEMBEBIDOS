/*
 * LCD16X2.c
 *
 * Created: 28/07/2019 21:01:10
 * Author : Marlon
 */ 

#include "LCD16X2.h"

char suscribete[] = "Suscribete,";
char prr[] = "Prr ";

int main(void)
{
    lcd_init();

    while (1)
	{
		PORTD &=~ (1<<PORTD2);
	        lcd_write(LCD_INST, CLEAR);
		lcd_print("T: 35.0C  ");
	        lcd_write(LCD_INST, LINEA2 );
		lcd_print("H: 64.2 %");
		
	   
	         _delay_ms(3000);
		
	}
}

